CREATE TABLE member (
  [UserID] int NOT NULL,
  [Username] varchar(20) NOT NULL,
  [Password] varchar(20) NOT NULL,
  [Email] varchar(100) NOT NULL,
  PRIMARY KEY  ([UserID]),
  CONSTRAINT [Username] UNIQUE  ([Username])
) ;

INSERT INTO member VALUES (001, 'win', 'win123', 'win@gmail.com');
INSERT INTO member VALUES (002, 'chai', 'chai123', 'chai@gmail.com');