<?php
session_start();

// initializing variables
$username = "root";
$email    = "";
$errors = array();

// connect to the database
//$db = mysqli_connect('localhost', 'root', '', 'test_sample');
$serverName = "ADMIN";
$dbName = "test";

$connectionInfo = array("Database"=>$dbName, "MultipleActiveResultSets"=>true, "CharacterSet"  => 'UTF-8');
$db = sqlsrv_connect( $serverName, $connectionInfo);
if( $db === false ) {
     die( print_r( sqlsrv_errors(), true));
}
// REGISTER USER
// ...
// ...

// LOGIN USER
if (isset($_POST['login_user'])) {
  $username = $_POST['username'];
  $password = $_POST['password'];

  if (empty($username)) {
  	array_push($errors, "Username is required");
  }
  if (empty($password)) {
  	array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
  	$query = "SELECT * FROM member WHERE Username=? AND Password=?";
	$parameters = [$username, $password];
  	$results = sqlsrv_query($db, $query, $parameters);
	$objResult = sqlsrv_fetch_array($results,SQLSRV_FETCH_ASSOC);
  	if ($objResult) {
  	  $_SESSION['username'] = $username;
  	  $_SESSION['success'] = "You are now logged in";
  	  header('location: index.php');
  	}else {
  		array_push($errors, "Wrong username/password combination");
  	}
  }
}

?>
